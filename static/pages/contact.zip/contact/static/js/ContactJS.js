
    function myClick() {
        document.getElementById("button").style.display = "none";
        document.getElementById("sent").innerHTML = "Thank you for contacting us";
    }